# colvar: a handy tool to read COLVAR file from Plumed

Read a COLVAR file
